import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.ObjectInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Order extends Menu implements Serializable{ // FoodMenu를 상속
	private int orderQuantity; // 주문 수량 정의
	
	public Order(String menuName, int price, int orderQuantity) { // 객체 생성자
		super(menuName, price); // FoodMenu의 메뉴 이름, 가격 가져오기
		this.orderQuantity = orderQuantity;
	}
	
	public String getMenuName() {
		return menuName;
	}
	public int gerPrice() {
		return price;
	}
	
	public int getOrderQuantity() {
		return orderQuantity; // 수량 접근자
	}
	
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity; // 수량 설정자
	}
	
	public int pay() {
		return orderQuantity * getPrice(); // 주문 수량 * 가격
	}
	// 주문 정보 저장
	public void saveOrder(ObjectOutputStream oos) throws IOException {
		//oos.defaultWriteObject();
        //oos.writeUTF(getMenuName()); // 메뉴 이름 저장
        //oos.writeInt(getPrice());    // 메뉴 가격 저장
        oos.writeObject(this); // Order 객체를 직렬화하여 저장
    }
	// 주문 정보 읽어오기
    public static Order readOrder(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    	return (Order) ois.readObject(); 
    }
    //---------------------
    // 주문 정보 저장
 	public void saveOrderWithDataStream(DataOutputStream dos) throws IOException {
         dos.writeUTF(menuName); // 메뉴 이름 저장
         dos.writeInt(price); // 메뉴 가격 저장
         dos.writeInt(orderQuantity); // 주문 수량 저장
     }
 	// 주문 정보 읽어오기
     public void readOrderWithDataStream(DataInputStream dis) throws IOException {
         this.menuName = dis.readUTF(); // 메뉴 이름 읽어오기
         this.price = dis.readInt(); // 메뉴 가격 읽어오기
         this.orderQuantity = dis.readInt(); //주문 수량 읽어오기    
     }
}
