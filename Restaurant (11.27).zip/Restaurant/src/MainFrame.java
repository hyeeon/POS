import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;


public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private RestaurantSystem res;
	private JButton tableButton; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		setLocationRelativeTo(null);
		res = new RestaurantSystem();
		
		// 데이터 불러오기
        try {
            res.readData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "데이터 읽기 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
        }

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		getContentPane().setLayout(new BorderLayout());
		
		// 상단 패널 생성
	    JPanel topPanel = new JPanel();
	    topPanel.setBackground(Color.LIGHT_GRAY);
	    topPanel.setPreferredSize(new Dimension(0, 50)); // 높이를 50픽셀로 설정
	    //topPanel.setBackground(Color.LIGHT_GRAY);
	    topPanel.setLayout(new BorderLayout());
	        
	    // 레스토랑 레이블 생성
	    JLabel label = new JLabel("  RESTAURANT");
	    label.setFont(new Font("Arial", Font.BOLD, 18));
	    label.setPreferredSize(new Dimension(150, 30));
	    topPanel.add(label, BorderLayout.WEST);

	    // 버튼 패널 생성
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.setBackground(Color.LIGHT_GRAY);
	    buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
	    JButton managerMenu = new JButton("관리자 메뉴");
        managerMenu.setPreferredSize(new Dimension(100, 45));
        managerMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ManagerFrame managerFrame = new ManagerFrame(); // ManagerFrame을 생성
                managerFrame.setVisible(true); // ManagerFrame을 표시
                dispose(); // 현재의 MainFrame을 닫음
            }
        });
        
        JButton save = new JButton("저장");
		save.setPreferredSize(new Dimension(60, 45));
	    save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                	res.saveData();
                    JOptionPane.showMessageDialog(null, "데이터 저장 완료", "성공", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "데이터 저장 실패 : " + ex.getMessage(), "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		buttonPanel.add(managerMenu);
		buttonPanel.add(save);
		
	    topPanel.add(buttonPanel, BorderLayout.EAST);
	        
	        
	        
	    // 중앙 패널 생성
	    JPanel centerPanel = new JPanel();
	    
	    ArrayList<Table> tables = res.getTables();
	    
	    
	    for (Table table : tables) {
            tableButton = createTableButton(table);
            centerPanel.add(tableButton);
            
        }
        contentPane.setLayout(new BorderLayout(0, 0));

        //패널들 추가
        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(centerPanel, BorderLayout.CENTER);
        centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
	}
	
	private JButton createTableButton(Table table) {
        JButton tableButton = new JButton(table.getId()+ " ( 수용인원 : " + table.getCapacity() + ")");
        tableButton.setFont(new Font("맑은 고딕", Font.PLAIN, 10)); // 버튼 폰트 설정
        tableButton.setPreferredSize(new Dimension(150, 100)); // 크기 조절
        updateTableButtonColor(tableButton, table.isAvailable());  // 초기 상태에 따라 색상 업데이트
        tableButton.addMouseListener(new MouseAdapter() {
            @Override
            //우클릭시 체크인 
            public void mouseClicked(MouseEvent e) {
            	if (SwingUtilities.isRightMouseButton(e)) {
                    if (table.isAvailable()) {
                        table.setAvailable(false);
                    } else {
                        table.setAvailable(true);
                    }
                    updateTableButtonColor(tableButton, table.isAvailable());
                } else if (e.getClickCount() == 1) {
                    OrderFrame orderFrame = new OrderFrame(table);
                    orderFrame.setVisible(true);
                }
            }
        });
        return tableButton;
	}
	private void updateTableButtonColor(JButton tableButton, boolean available) {
	    if (available) {
	        tableButton.setBackground(null);
	    } else {
	        tableButton.setBackground(Color.GRAY);
	    }
	}
	
}
