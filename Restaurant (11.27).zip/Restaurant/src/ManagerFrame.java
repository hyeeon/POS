import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.SimpleAttributeSet;

public class ManagerFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private RestaurantSystem res;
	private DefaultTableModel tableModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerFrame frame = new ManagerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		res = new RestaurantSystem();
		setContentPane(contentPane);
		getContentPane().setLayout(new BorderLayout());
		try {
	        res = new RestaurantSystem();
	        res.readData(); // 데이터를 읽어오기
	    } catch (Exception ex) {
	    	JOptionPane.showMessageDialog(null, "데이터 읽기 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
	    }
		
		// 상단 패널 생성
	    JPanel topPanel = new JPanel();
	    topPanel.setBackground(Color.LIGHT_GRAY);
	    topPanel.setPreferredSize(new Dimension(0, 50)); // 높이 설정
	    //topPanel.setBackground(Color.LIGHT_GRAY);
	    topPanel.setLayout(new BorderLayout());
	    
	    //라벨 생성
	    JLabel lblT = new JLabel("  관리자 메뉴");
	    lblT.setFont(new Font("맑은 고딕", Font.BOLD, 20));
	    lblT.setPreferredSize(new Dimension(150, 30));
	    topPanel.add(lblT, BorderLayout.WEST);
	    
	    // 중앙 패널 생성
	    JPanel centerPanel = new JPanel();
        centerPanel.setLayout(null);
        
        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(centerPanel, BorderLayout.CENTER);
        
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 370, 421);
        panel.setLayout(null);
        centerPanel.add(panel);
        
        //TableModel 생성
        ArrayList<Table> tables = res.getTables();
        Object[][] data = new Object[tables.size()][2];
        for (int i = 0; i < tables.size(); i++) {
            Table table = tables.get(i);
            data[i][0] = table.getId();
            data[i][1] = table.getCapacity();
        }

        String[] columnNames = {"테이블 이름", "수용 인원"};
        tableModel = new DefaultTableModel(data, columnNames);

        // JTable에 TableModel 설정
        table = new JTable(tableModel) {
        	@Override
        	public boolean isCellEditable(int row, int column) {
        		return false;
        	}
        };
        table.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.setRowHeight(30);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setFont(new Font("맑은 고딕", Font.BOLD, 15));
        DefaultTableCellRenderer cellAlignCenter = new DefaultTableCellRenderer();
        cellAlignCenter.setHorizontalAlignment(JLabel.CENTER);
        table.getColumn("테이블 이름").setCellRenderer(cellAlignCenter);
        table.getColumn("수용 인원").setCellRenderer(cellAlignCenter);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                
                if (selectedRow != -1 && e.getClickCount() == 2) {
                    // 더블 클릭이면 선택 취소
                    table.clearSelection();
                }
            }
        });
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(368, 0, 370, 421);
        panel_1.setLayout(null);
        centerPanel.add(panel_1);
        
        //TableModel 생성
        ArrayList<Menu> menuList = res.getMenu();
        Object[][] menuData = new Object[menuList.size()][2];
        for (int i = 0; i < menuList.size(); i++) {
            Menu menuItem = menuList.get(i);
            menuData[i][0] = menuItem.getMenuName();
            menuData[i][1] = menuItem.getPrice();
        }

        String[] menuColumnNames = {"메뉴 이름", "가격"};
        DefaultTableModel menuTableModel = new DefaultTableModel(menuData, menuColumnNames);

        // JTable에 TableModel 설정
        table_1 = new JTable(menuTableModel);
        table_1.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        table_1.getColumnModel().getColumn(0).setPreferredWidth(50);
        table_1.setRowHeight(30);
        table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table_1.getTableHeader().setFont(new Font("맑은 고딕", Font.BOLD, 15));
        //DefaultTableCellRenderer cellAlignCenter = new DefaultTableCellRenderer();
        cellAlignCenter.setHorizontalAlignment(JLabel.CENTER);
        
        table_1.getColumn("메뉴 이름").setCellRenderer(cellAlignCenter);
        table_1.getColumn("가격").setCellRenderer(cellAlignCenter);
    
        // JScrollPane에 테이블 추가
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 44, 370, 379);
        
        JScrollPane scrollPane_1 = new JScrollPane(table_1);
        scrollPane_1.setBounds(0, 44, 370, 377);

        // JScrollPane을 rPanel에 추가
        panel.add(scrollPane);
        panel_1.add(scrollPane_1);
        
        JTextPane textPane = new JTextPane();
        textPane.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        textPane.setText("테이블 관리");
        textPane.setBounds(0, 5, 370, 40);
        
        // 가운데 정렬
        StyledDocument doc = textPane.getStyledDocument();
        SimpleAttributeSet center = new SimpleAttributeSet();
        StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
        doc.setParagraphAttributes(0, doc.getLength(), center, false);

        
        panel.add(textPane);
        
        JTextPane textPane_1 = new JTextPane();
        textPane_1.setText("메뉴 관리");
        textPane_1.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        textPane_1.setBounds(0, 5, 370, 40);
        
        // 가운데 정렬
        StyledDocument doc1 = textPane_1.getStyledDocument();
        SimpleAttributeSet center1 = new SimpleAttributeSet();
        StyleConstants.setAlignment(center1, StyleConstants.ALIGN_CENTER);
        doc1.setParagraphAttributes(0, doc1.getLength(), center1, false);

        
        panel_1.add(textPane_1);

        
        JPanel panel_2 = new JPanel();
        panel_2.setBounds(0, 422, 370, 81);
        centerPanel.add(panel_2);
        panel_2.setLayout(new GridLayout(0, 3, 0, 0));
        
        JButton btnNewButton = new JButton("추가");
        btnNewButton.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        panel_2.add(btnNewButton);
        
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                while (true) {
                    // 다이얼로그 창 띄우기
                    JPanel panel = new JPanel();
                    panel.setLayout(new GridLayout(2, 2));

                    JTextField newTableNumberField = new JTextField();
                    JTextField newCapacityField = new JTextField();

                    panel.add(new JLabel("테이블 이름:"));
                    panel.add(newTableNumberField);
                    panel.add(new JLabel("수용 인원:"));
                    panel.add(newCapacityField);

                    // 다이얼로그 창의 엑스 버튼을 누르면 취소 버튼을 누른 것으로 처리
                    JDialog dialog = new JDialog();
                    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

                    int result = JOptionPane.showConfirmDialog(dialog, panel, "테이블 추가", JOptionPane.OK_CANCEL_OPTION);

                    if (result == JOptionPane.CANCEL_OPTION) {
                        break;  // 취소 버튼을 누르거나 다이얼로그 창을 닫으면 종료
                    }

                    try {
                        String newTableNumber = newTableNumberField.getText();
                        String newCapacity = newCapacityField.getText();

                        // 사용자가 취소 버튼을 눌렀거나, 입력이 없을 경우 예외 처리
                        if (newTableNumber.isEmpty() || newCapacity.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "테이블 이름과 수용 인원을 모두 입력해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                            continue;  // 다시 입력창 띄우기 위해 루프 다시 시작
                        }

                        // 테이블 번호 중복 검사
                        if (res.getTable(newTableNumber) != null) {
                            JOptionPane.showMessageDialog(null, newTableNumber + " 테이블은 이미 존재합니다.", "경고", JOptionPane.WARNING_MESSAGE);
                            continue;  // 다시 입력창 띄우기 위해 루프 다시 시작
                        }

                        int newCapacityValue = Integer.parseInt(newCapacity);

                        // 새로운 테이블 추가
                        Table newTable = new Table(newTableNumber, newCapacityValue);
                        tables.add(newTable);

                        // JTable 업데이트
                        Object[] rowData = {newTableNumber, newCapacityValue}; // 새로운 행 데이터
                        tableModel.addRow(rowData); // 행 추가

                        break;  // 정상적으로 추가되면 루프 탈출

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "수용 인원은 숫자로 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        JButton btnNewButton_1 = new JButton("수정");
        btnNewButton_1.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();

                if (selectedRow != -1) { // 선택된 행이 없는 경우
                	while (true) {
	                    // 선택된 행의 데이터 가져오기
	                    String tableNumber = (String) tableModel.getValueAt(selectedRow, 0);
	                    int capacity = (int) tableModel.getValueAt(selectedRow, 1);
	
	                    // 다이얼로그 창 띄우기
	                    JPanel panel = new JPanel();
	                    panel.setLayout(new GridLayout(2, 2));
	
	                    JTextField newTableNumberField = new JTextField(tableNumber);
	                    JTextField newCapacityField = new JTextField(String.valueOf(capacity));
	
	                    panel.add(new JLabel("새로운 테이블 이름:"));
	                    panel.add(newTableNumberField);
	                    panel.add(new JLabel("새로운 수용 인원:"));
	                    panel.add(newCapacityField);
	
	                    int result = JOptionPane.showConfirmDialog(null, panel, "테이블 수정", JOptionPane.OK_CANCEL_OPTION);
	
	                    if (result == JOptionPane.CANCEL_OPTION) {
	                        break;  // 취소 버튼을 누르면 루프 탈출
	                    }
	                    try {
	                    	String newTableNumber = newTableNumberField.getText();
	                        String newCapacity = newCapacityField.getText();
	
	                        // 사용자가 취소 버튼을 눌렀거나, 입력이 없을 경우 예외 처리
	                        if (newTableNumber == null || newCapacity == null ||
	                                newTableNumber.isEmpty() || newCapacity.isEmpty()) {
	                            return;
	                        }
	                        // 테이블 번호 중복 검사
	                        boolean isDuplicate = false;
	                        for (int i = 0; i < tableModel.getRowCount(); i++) {
	                            if (i != selectedRow) { // 현재 행은 제외하고 검사
	                                String existingTableNumber = (String) tableModel.getValueAt(i, 0);
	                                if (newTableNumber.equals(existingTableNumber)) {
	                                    isDuplicate = true;
	                                    break;
	                                }
	                            }
	                        }
	
	                        if (isDuplicate) {
	                            JOptionPane.showMessageDialog(null, newTableNumber + " 테이블은 이미 존재합니다.", "경고", JOptionPane.WARNING_MESSAGE);
	                            continue;  // 다시 입력창 띄우기 위해 루프 다시 시작
	                        }
	
	                        int newCapacityValue = Integer.parseInt(newCapacity);
	
	                        // 수정된 내용으로 업데이트
	                        tableModel.setValueAt(newTableNumber, selectedRow, 0);
	                        tableModel.setValueAt(newCapacityValue, selectedRow, 1);
	
	                        // 데이터도 업데이트 (res는 여기서 사용된 변수명일 것으로 가정합니다)
	                        Table updatedTable = res.getTables().get(selectedRow);
	                        updatedTable.setId(newTableNumber);
	                        updatedTable.setCapacity(newCapacityValue);
	                        
	                        break; // 정상적으로 수정했을 때 루프 탈출
	
	                    } catch (NumberFormatException ex) {
	                        JOptionPane.showMessageDialog(null, "수용 인원은 숫자로 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
	                    }
                	}

                } else {
                    JOptionPane.showMessageDialog(null, "수정할 행을 선택해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        panel_2.add(btnNewButton_1);
        
        JButton btnNewButton_2 = new JButton("삭제");
        btnNewButton_2.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        panel_2.add(btnNewButton_2);
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                
                if (selectedRow != -1) { // 선택된 행이 있는지 확인
                    // 행 삭제
                    tableModel.removeRow(selectedRow);
                    res.getTables().remove(selectedRow); // 데이터도 삭제
                } else {
                    JOptionPane.showMessageDialog(null, "삭제할 행을 선택해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        JPanel panel_3 = new JPanel();
        panel_3.setBounds(368, 422, 370, 81);
        centerPanel.add(panel_3);
        panel_3.setLayout(new GridLayout(0, 3, 0, 0));
        
        JButton btnNewButton_3 = new JButton("추가");
        btnNewButton_3.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        panel_3.add(btnNewButton_3);
        btnNewButton_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	while (true) {
	            	// 다이얼로그 창 띄우기
	                JPanel panel = new JPanel();
	                panel.setLayout(new GridLayout(2, 2));
	
	                JTextField menuNameField = new JTextField();
	                JTextField priceField = new JTextField();
	
	                panel.add(new JLabel("메뉴 이름:"));
	                panel.add(menuNameField);
	                panel.add(new JLabel("가격:"));
	                panel.add(priceField);
	
	                int result = JOptionPane.showConfirmDialog(null, panel, "메뉴 추가", JOptionPane.OK_CANCEL_OPTION);
	                
	                if (result == JOptionPane.CANCEL_OPTION) {
	                    break;  // 취소 버튼을 누르면 루프 탈출
	                }

                    try {
                        String menuName = menuNameField.getText();
                        String priceString = priceField.getText();

                        // 사용자가 취소 버튼을 눌렀거나, 입력이 없을 경우 예외 처리
                        if (menuName.isEmpty() || priceString.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "메뉴 이름과 가격을 모두 입력해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                            continue;
                        }

                        // 메뉴 이름 중복 검사
                        if (res.getMenuItem(menuName) != null) {
                            JOptionPane.showMessageDialog(null, menuName + " 메뉴는 이미 존재합니다.", "경고", JOptionPane.WARNING_MESSAGE);
                            continue;
                        }

                        int priceValue = Integer.parseInt(priceString);

                        // 새로운 메뉴 추가
                        Menu newMenu = new Menu(menuName, priceValue);
                        menuList.add(newMenu);

                        // JTable 업데이트 
                        Object[] rowData = {menuName, priceValue}; // 새로운 행 데이터
                        menuTableModel.addRow(rowData); // 행 추가
                        
                        break;  // 정상적으로 추가되면 루프 탈출

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "가격은 숫자로 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        JButton btnNewButton_4 = new JButton("수정");
        btnNewButton_4.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        panel_3.add(btnNewButton_4);
        
        btnNewButton_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table_1.getSelectedRow();

                if (selectedRow != -1) { // 선택된 행이 있는지 확인
                	while (true) {
                        // 선택된 행의 데이터 가져오기
                        String menuName = (String) menuTableModel.getValueAt(selectedRow, 0);
                        int price = (int) menuTableModel.getValueAt(selectedRow, 1);

                        // 다이얼로그 창 띄우기
                        JPanel panel = new JPanel();
                        panel.setLayout(new GridLayout(2, 2));

                        JTextField newMenuNameField = new JTextField(menuName);
                        JTextField newPriceField = new JTextField(String.valueOf(price));

                        panel.add(new JLabel("새로운 메뉴명:"));
                        panel.add(newMenuNameField);
                        panel.add(new JLabel("새로운 가격:"));
                        panel.add(newPriceField);

                        int result = JOptionPane.showConfirmDialog(null, panel, "메뉴 수정", JOptionPane.OK_CANCEL_OPTION);

                        if (result == JOptionPane.CANCEL_OPTION) {
                            break;  // 취소 버튼을 누르면 루프 탈출
                        }

                        try {
                            String newMenuName = newMenuNameField.getText();
                            String newPrice = newPriceField.getText();

                            // 사용자가 취소 버튼을 눌렀거나, 입력이 없을 경우 예외 처리
                            if (newMenuName.isEmpty() || newPrice.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "새로운 메뉴명과 가격을 모두 입력해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                                continue;  // 다시 입력창 띄우기 위해 루프 다시 시작
                            }

                            // 메뉴 이름 중복 검사
                            boolean isDuplicate = false;
                            for (int i = 0; i < menuTableModel.getRowCount(); i++) {
                                if (i != selectedRow) { // 현재 행은 제외하고 검사
                                    String existingMenuName = (String) menuTableModel.getValueAt(i, 0);
                                    if (newMenuName.equals(existingMenuName)) {
                                        isDuplicate = true;
                                        break;
                                    }
                                }
                            }
                            if (isDuplicate) {
                                JOptionPane.showMessageDialog(null, newMenuName + " 메뉴는 이미 존재합니다.", "경고", JOptionPane.WARNING_MESSAGE);
                                continue;  // 다시 입력창 띄우기 위해 루프 다시 시작
                            }
                            
                            int newPriceValue = Integer.parseInt(newPrice);

                            // 수정된 내용으로 업데이트
                            menuTableModel.setValueAt(newMenuName, selectedRow, 0);
                            menuTableModel.setValueAt(newPriceValue, selectedRow, 1);

                            // 데이터도 업데이트
                            Menu updatedMenu = res.getMenu().get(selectedRow);
                            updatedMenu.setMenuName(newMenuName);
                            updatedMenu.setPrice(newPriceValue);

                            break;  // 정상적으로 수정했을 때 루프 탈출

                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "가격은 숫자로 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "수정할 행을 선택해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        
        JButton btnNewButton_5 = new JButton("삭제");
        btnNewButton_5.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        panel_3.add(btnNewButton_5);
        
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table_1.getSelectedRow();

                if (selectedRow != -1) { // 선택된 행이 있는지 확인
                    // 선택된 행의 데이터 가져오기
                    String menuName = (String) menuTableModel.getValueAt(selectedRow, 0);

                    // 사용자에게 삭제 여부 확인
                    int result = JOptionPane.showConfirmDialog(null, menuName + " 메뉴를 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
                    if (result == JOptionPane.YES_OPTION) {
                        // JTable 및 ArrayList에서 삭제
                        menuTableModel.removeRow(selectedRow);
                        res.removeMenu(menuName);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "삭제할 행을 선택해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        
        JPanel panel_4 = new JPanel();
        panel_4.setBounds(738, 0, 138, 503);
        centerPanel.add(panel_4);
        panel_4.setLayout(null);
        
        JButton btnNewButton_6 = new JButton("저장하기");
        btnNewButton_6.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        btnNewButton_6.setBounds(18, 6, 120, 80);
        panel_4.add(btnNewButton_6);
        
        btnNewButton_6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                	res.saveData();
                    JOptionPane.showMessageDialog(null, "데이터 저장 완료", "성공", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "데이터 저장 실패 : " + ex.getMessage(), "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        
        JButton btnNewButton_7 = new JButton("뒤로가기");
        btnNewButton_7.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        btnNewButton_7.setBounds(18, 423, 120, 80);
        btnNewButton_7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
                dispose(); // 현재 ManagerFrame 닫기
            }
        });
        panel_4.add(btnNewButton_7);
	}
}
