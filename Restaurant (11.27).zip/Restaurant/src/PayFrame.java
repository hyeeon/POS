import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PayFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private RestaurantSystem res;
	private Table table;
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private JTextField textField;
    
   
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PayFrame frame = new PayFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/

	/**
	 * Create the frame.
	 */
	public PayFrame(Table table) {

		this.table = table;
		try {
            // 주문 목록을 파일에서 읽어옴
            res.readData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "주문 목록 읽기 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
        }
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 720, 480);
		setLocationRelativeTo(null);
		res = new RestaurantSystem();

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

        // 상단 패널 생성
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.LIGHT_GRAY);
        topPanel.setPreferredSize(new Dimension(0, 40));
        topPanel.setLayout(new BorderLayout());

        // 선택된 테이블의 이름 가져오기
        String tableName = (table != null) ? table.getId() : "";

        // 테이블 이름 레이블 생성
        JLabel label = new JLabel("  " + tableName);
        label.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        label.setPreferredSize(new Dimension(150, 30));
        topPanel.add(label, BorderLayout.WEST);
        

	    // 버튼 패널 생성
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.setBackground(Color.LIGHT_GRAY);
	    buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
	 
        JButton home = new JButton("홈");
        home.setFont(new Font("굴림", Font.PLAIN, 14));
		home.setPreferredSize(new Dimension(60, 32));

		buttonPanel.add(home);

	    topPanel.add(buttonPanel, BorderLayout.EAST);
	        
	        
	        
	    // 중앙 패널 생성
	    JPanel centerPanel = new JPanel();
        contentPane.setLayout(new BorderLayout(0, 0));
	    
	    //패널 추가
        contentPane.add(topPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel);
        centerPanel.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("결제를 진행하시겠습니까?");
        lblNewLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        lblNewLabel.setBounds(10, 10, 210, 15);
        centerPanel.add(lblNewLabel);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(10, 35, 674, 294);
        panel_1.setLayout(new BorderLayout());
        centerPanel.add(panel_1);
        
        // 테이블 모델 생성
        ArrayList<Order> orders = table.getOrders();
        Object[][] data = new Object[orders.size()][4];
        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            data[i][0] = order.getMenuName();
            data[i][1] = order.getPrice();
            data[i][2] = order.getOrderQuantity();
            data[i][3] = order.pay();
        }

        String[] columnNames = {"메뉴명", "가격", "수량", "금액"};
        tableModel = new DefaultTableModel(data, columnNames);

        // 테이블 생성
        orderTable = new JTable(tableModel);
        orderTable.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        orderTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        orderTable.setRowHeight(30);
        orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        orderTable.getTableHeader().setFont(new Font("맑은 고딕", Font.BOLD, 15));
        DefaultTableCellRenderer cellAlignCenter = new DefaultTableCellRenderer();
        cellAlignCenter.setHorizontalAlignment(JLabel.CENTER);
        orderTable.getColumn("메뉴명").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("가격").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("수량").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("금액").setCellRenderer(cellAlignCenter);

        // 테이블에 스크롤 추가
        JScrollPane scrollPane = new JScrollPane(orderTable);
        panel_1.add(scrollPane, BorderLayout.CENTER);
        
        JButton btnNewButton = new JButton("돌아가기");
        btnNewButton.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        btnNewButton.setBounds(430, 340, 120, 40);
        centerPanel.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 현재 창을 닫음
                dispose();
            }
        });
        
        JButton btnNewButton_1 = new JButton("결제");
        btnNewButton_1.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        btnNewButton_1.setBounds(564, 340, 120, 40);
        centerPanel.add(btnNewButton_1);
        
        JLabel lblNewLabel_1 = new JLabel("총 금액");
        lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(20, 344, 91, 30);
        centerPanel.add(lblNewLabel_1);
        
        textField = new JTextField();
        textField.setBounds(102, 352, 194, 21);
        centerPanel.add(textField);
        textField.setColumns(10);
	
	    // 텍스트 필드에 총 금액이 나오도록 설정
	    int totalAmount = table.getTotalAmount();
	    textField.setText(String.valueOf(totalAmount));

        
        btnNewButton_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                	// 주문 목록을 비움
                    table.clearOrders();

                    // 테이블의 available을 true로 변경
                    table.setAvailable(true);

                    // 현재 창을 닫음
                    dispose();

                    // 결제가 완료 메세지 창
                    JOptionPane.showMessageDialog(null, "결제가 완료되었습니다. 안녕히 가세요.", "알림", JOptionPane.INFORMATION_MESSAGE);
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "주문 내역 초기화 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        

        JPanel panel = new JPanel();
        panel.setBounds(10, 10, 330, 310);

        
    }
}
