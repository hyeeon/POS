import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;

public class OrderFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Table table; // 현재 주문을 관리하는 데 사용되는 필드
    private Table selectedTable; // 주문 프레임에서 선택된 테이블을 저장하는 데 사용되는 필드
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private DefaultTableModel orderTableModel;
    private RestaurantSystem res;
    private JButton menuButton;  // 메뉴 버튼을 저장할 필드
	/**
	 * Launch the application.
	 */
    /*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrderFrame frame = new OrderFrame(table);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	
	/**
	 * Create the frame.
	 */
	
	public OrderFrame(Table table) {
		this.table = table;
		this.selectedTable = table; // 생성자를 통해 데이터 전달
		
        setResizable(false);
		setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 720, 480);
        setLocationRelativeTo(null);
		res = new RestaurantSystem();
        
        try {
	        res.readData(); // 데이터를 읽어오기
	    } catch (Exception ex) {
	    	JOptionPane.showMessageDialog(null, "데이터 읽기 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
	    }
        
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        
		setContentPane(contentPane);

        // 상단 패널 생성
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.LIGHT_GRAY);
        topPanel.setPreferredSize(new Dimension(0, 40));
        topPanel.setLayout(new BorderLayout());

        // 선택된 테이블의 이름 가져오기
        String tableName = (table != null) ? table.getId() : "";

        // 테이블 이름 레이블 생성
        JLabel label = new JLabel("  " + tableName);
        label.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        label.setPreferredSize(new Dimension(150, 30));
        topPanel.add(label, BorderLayout.WEST);
        

	    // 버튼 패널 생성
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.setBackground(Color.LIGHT_GRAY);
	    buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
	 
        JButton home = new JButton("홈");
        home.setFont(new Font("굴림", Font.PLAIN, 14));
		home.setPreferredSize(new Dimension(60, 32));
		home.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        dispose(); // 현재 프레임 닫기
		    }
		});
		buttonPanel.add(home);

	    topPanel.add(buttonPanel, BorderLayout.EAST);
	        
	        
	        
	    // 중앙 패널 생성
	    JPanel centerPanel = new JPanel();
        contentPane.setLayout(new BorderLayout(0, 0));
	    
	    //패널 추가
        contentPane.add(topPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel);
        centerPanel.setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBounds(10, 10, 330, 310);
        

        // TableModel 생성
        ArrayList<Order> orders = table.getOrders();
        Object[][] data = new Object[orders.size()][4];
        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            data[i][0] = order.getMenuName();
            data[i][1] = order.getPrice();
            data[i][2] = order.getOrderQuantity();
            data[i][3] = order.pay();// 수정된 부분: 테이블의 총 주문 금액 추가
        }

        String[] columnNames = {"메뉴명", "가격", "수량","금액"}; // 열 이름 업데이트
        tableModel = new DefaultTableModel(data, columnNames);

        // JTable에 TableModel 설정
        orderTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        orderTable.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        orderTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        orderTable.setRowHeight(30);
        orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        orderTable.getTableHeader().setFont(new Font("맑은 고딕", Font.BOLD, 15));
        DefaultTableCellRenderer cellAlignCenter = new DefaultTableCellRenderer();
        cellAlignCenter.setHorizontalAlignment(JLabel.CENTER);
        orderTable.getColumn("메뉴명").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("가격").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("수량").setCellRenderer(cellAlignCenter);
        orderTable.getColumn("금액").setCellRenderer(cellAlignCenter);
	
		
		orderTable.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        if (SwingUtilities.isRightMouseButton(e) && e.getClickCount() == 1) {
		            int selectedRow = orderTable.getSelectedRow();
		            if (selectedRow != -1) {
		                // 선택된 행의 메뉴를 가져옴
		                String selectedMenuName = (String) tableModel.getValueAt(selectedRow, 0);
		                // 현재 테이블의 메뉴 목록에서 같은 메뉴 찾기
		                ArrayList<Order> orders = table.getOrders();
		                for (Order order : orders) {
		                    if (order.getMenuName().equals(selectedMenuName)) {
		                        // 주문 목록에 있는 메뉴면 수량을 1 감소
		                        order.setOrderQuantity(Math.max(1, order.getOrderQuantity() - 1));
		                        // 주문 테이블 업데이트
		                        updateOrderTable();
		                        break;
		                    }
		                }
		            }
		        }
		    }
		});

        panel.setLayout(new BorderLayout(0, 0));
        JScrollPane scrollPane = new JScrollPane(orderTable);
        panel.add(scrollPane);
        
        centerPanel.add(panel);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(355, 10, 330, 310);
        centerPanel.add(panel_1);
        

	    ArrayList<Menu> menus = res.getMenu();
	    
	    
	    for (Menu menu : menus) {
            menuButton = createMenuButton(menu);
            panel_1.add(menuButton);
            menuButton.addMouseListener(new MouseAdapter() {

            });
        }
        
        JButton btnNewButton = new JButton("주문");
        btnNewButton.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        btnNewButton.setBounds(360, 335, 140, 40);
        centerPanel.add(btnNewButton);
		
		btnNewButton.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // 주문 목록 저장
		            res.saveData();
		
		            // 현재 창을 닫음
		            dispose();
		        } catch (Exception ex) {
		            JOptionPane.showMessageDialog(null, "주문 목록 저장 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});
        JButton btnNewButton_1 = new JButton("결제");
        btnNewButton_1.setFont(new Font("맑은 고딕", Font.PLAIN, 15));
        btnNewButton_1.setBounds(540, 335, 140, 40);
        centerPanel.add(btnNewButton_1);
        btnNewButton_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            	try {
                    // 주문 목록을 저장
                    res.saveData();
                    dispose();
                    // PayFrame을 생성하면서 선택된 테이블 정보를 전달
                    PayFrame payFrame = new PayFrame(selectedTable);
                    payFrame.setVisible(true); // PayFrame을 표시
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "주문 목록 저장 실패: " + ex.getMessage(), "에러", JOptionPane.ERROR_MESSAGE);
                }
        
            }
        });
	}
	
	private JButton createMenuButton(Menu menu) {
        JButton menuButton = new JButton("<html><div style='text-align: center;'>" + menu.getMenuName()+ "<br>" + menu.getPrice()+ "원</div></html>");
        menuButton.setFont(new Font("맑은 고딕", Font.PLAIN, 10)); // 버튼 폰트 설정
        menuButton.setPreferredSize(new Dimension(100, 50)); // 크기 조절
        menuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 메뉴 버튼을 클릭하면 주문 테이블에 해당 메뉴를 추가 또는 수량을 증가
                OrderMenu(menu);
            }
        });
        return menuButton;
	}
	// 주문 테이블에 메뉴 추가 또는 수량 증가하는 메서드
	private void OrderMenu(Menu menu) {
		// 현재 테이블의 메뉴 목록에서 같은 메뉴 찾기
	    ArrayList<Order> orders = table.getOrders();
	    for (Order order : orders) {
	        if (order.getMenuName().equals(menu.getMenuName())) {
	            // 이미 주문 목록에 있는 메뉴면 수량을 증가
	            order.setOrderQuantity(order.getOrderQuantity() + 1);
	            updateOrderTable();
	            return; // 메서드 종료
	        }
	    }

	    // 주문 목록에 없는 메뉴면 새로 추가
	    int selectedRow = tableModel.getRowCount();
	    tableModel.addRow(new Object[4]);
	    tableModel.setValueAt(menu.getMenuName(), selectedRow, 0);
	    tableModel.setValueAt(menu.getPrice(), selectedRow, 1);
	    tableModel.setValueAt(1, selectedRow, 2); // 기본 수량 1로 설정
	    tableModel.setValueAt(new Order(menu.getMenuName(), menu.getPrice(), 1).pay(), selectedRow, 3); // 기본 금액 설정

	    // 주문 추가
	    Order newOrder = new Order(menu.getMenuName(), menu.getPrice(), 1);
	    table.addOrder(newOrder);
	    
	    updateOrderTable();
	}
	
	private void updateOrderTable() {
		ArrayList<Order> orders = table.getOrders();
	    Object[][] data = new Object[orders.size()][4];
	    for (int i = 0; i < orders.size(); i++) {
	        Order order = orders.get(i);
	        data[i][0] = order.getMenuName();
	        data[i][1] = order.getPrice();
	        data[i][2] = order.getOrderQuantity();
	        data[i][3] = order.pay();
	    }
	    tableModel.setDataVector(data, new Object[]{"메뉴명", "가격", "수량", "금액"});
	}
	
}
