import java.io.*;
import java.util.ArrayList;

public class RestaurantSystem {
	private ArrayList<Menu> menu; // 메뉴 리스트로 변경
	private ArrayList<Table> tables; // 테이블 리스트로 변경
	
	public RestaurantSystem() {
		menu = new ArrayList<>(); // 빈 ArrayList 초기화
		tables = new ArrayList<>(); // 빈 ArrayList 초기화
	}
	
	public ArrayList<Menu> getMenu() {
		return menu;
	}
	
	public int getMenuCount() {
		return menu.size(); // ArrayList의 크기를 반환
	}
	
	public ArrayList<Table> getTables() {
		return tables;
	}
	
	public Table getTable(String id) { // 테이블 접근자
		for (Table table : tables) {
			if (table != null && table.getId().equals(id)) { // getId() 함수를 사용하여 입력 받은 id와 비교
				return table; // 일치하면 테이블 반환
			}
		}
		return null; // 일치 안 하면 null 반환
	}
	
	public Menu getMenuItem(String menuName) { // 메뉴 이름 접근자
		for (Menu item : menu) {
			if (item.getMenuName().equals(menuName)) {
				return item;
			}
		}
		return null; // 일치 안 하면 null 반환
	}
	
	public void addTable(String id, int capacity) { // 테이블 추가 함수
		Table newTable = new Table(id, capacity); // 새로운 테이블 객체 생성
		tables.add(newTable); // ArrayList에 추가
	}

	public void addMenu(String menuName, int price) {
		if (getMenuItem(menuName) == null) {
            Menu newMenu = new Menu(menuName, price);
            menu.add(newMenu);
        } else {
            System.out.println(menuName + " 메뉴 이름이 이미 존재합니다.");
        }
	}

	
	public boolean removeTable(String id) {
		Table tableToRemove = null;
		for (Table table : tables) {
			if (table != null && table.getId().equals(id)) {
				tableToRemove = table;
				break;
			}
		}
		if (tableToRemove != null) {
			tables.remove(tableToRemove); // ArrayList에서 제거
			return true;
		} else {
			return false;
		}
	}
	
	public boolean removeMenu(String menuName) {
		Menu menuToRemove = null;
		for (Menu foodMenu : menu) {
			if (foodMenu.getMenuName().equals(menuName)) {
				menuToRemove = foodMenu;
				break;
			}
		}
		if (menuToRemove != null) {
			menu.remove(menuToRemove); // ArrayList에서 제거
			return true;
		} else {
			return false;
		}
	}
	

	public int searchTableID(Table table) { // 테이블 id search 함수
	    for (int i = 0; i < tables.size(); i++) {
	        if (tables.get(i).equals(table)) { // 테이블 id가 같은 게 있으면
	            return i; // ArrayList에서의 인덱스 값 반환
	        }
	    }
	    return -1; // 없으면 -1 반환
	}

	public int searchMenuName(Menu foodMenu) { // 메뉴 이름 search 함수
	    for (int i = 0; i < menu.size(); i++) {
	        if (menu.get(i).equals(foodMenu)) { // 메뉴 이름이 같은 게 있으면
	            return i; // ArrayList에서의 인덱스 값 반환
	        }
	    }
	    return -1; // 없으면 -1 반환
	}
	/*
	// 주문 정보 저장
    private void saveOrders(ObjectOutputStream oos) throws IOException {
        for (Table table : tables) {
            table.saveOrders(oos);
        }
    }

    // 주문 정보 읽어오기
    private void readOrders(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        for (Table table : tables) {
            table.readOrders(ois);
        }
    }
    */
	//데이터를 파일에 저장하기
	public void saveData() throws Exception{
        
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("restaurant.dat"));

        oos.writeObject(menu); // 메뉴 정보 저장
        oos.writeObject(tables); // 테이블 정보 저장


        oos.close();
        
    }
	
	//파일에서 데이터를 읽어오기
    public void readData() throws Exception, ClassNotFoundException {
    	ObjectInputStream ois = new ObjectInputStream(new FileInputStream("restaurant.dat"));

    	menu = (ArrayList<Menu>) ois.readObject(); // 메뉴 정보 읽어오기
        tables = (ArrayList<Table>) ois.readObject(); // 테이블 정보 읽어오기
        

        ois.close();
    }
	//---------------------------------------------------
	 //데이터를 파일에 저장하기
	public void saveDataWithDataStream() throws Exception{
        
          DataOutputStream dos = new DataOutputStream(new FileOutputStream("restaurant.dat"));

          for (Menu menu : getMenu()) {
              menu.saveMenuWithDataStream(dos); // 메뉴 정보 저장
          }

          for (Table table : getTables()) {
              table.saveTableWithDataStream(dos); // 테이블 정보 저장
              table.saveOrdersWithDataStream(dos); // 주문 정보 저장
          }

          dos.close();
        
    }
	//파일에서 데이터를 읽어오기
    public void readDataWithDataStream() throws Exception{
        
          DataInputStream dis = new DataInputStream(new FileInputStream("restaurant.dat"));

          for (Menu menu : getMenu()) {
              menu.readMenuWithDataStream(dis); // 메뉴 정보 읽어오기
          }

          for (Table table : getTables()) {
              table.readTableWithDataStream(dis); // 테이블 정보 읽어오기
              table.readOrdersWithDataStream(dis); // 주문 정보 읽어오기
          }

          dis.close();
    }
}
