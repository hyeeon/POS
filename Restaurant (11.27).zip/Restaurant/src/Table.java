import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;

public class Table implements Serializable {
	private String id; // 테이블 아이디 정의
	private int capacity; // 수용 인원 정의
	private boolean available; // 사용 가능 여부 정의
	private ArrayList<Order> orders;
	//private int orderCount;
	private int totalAmount;
	private static final long serialVersionUID = 481651623153800063L;
	
	public Table (String id, int capacity) { 
 		this.id = id;
		this.capacity = capacity;
		this.available = true; // 사용 가능 여부는 true로 기본값 설정
		this.orders = new ArrayList<>();
		this.totalAmount = 0;
	}
	
	public String getId() { // 테이블 아이디 접근자
		return id;
	}
	
	public int getCapacity() { // 수용인원 접근자
		return capacity;
	}
	
	public int getTotalAmount() { // 총액 접근자
		return totalAmount; 
	}
	
	public boolean isAvailable() { // 사용 여부 접근자
		return available;
	}
	
	public void setAvailable(boolean available) { // 사용 여부 설정자
		this.available = available;
	}
	public void setId(String id) {
        this.id = id;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
	
	public ArrayList<Order> getOrders() {
        return orders;
    }

	public int getOrderCount() {
		return orders.size(); // orderCount 접근자
	}
	
	public void addOrder(Order order) { // 주문 추가 함수
		if (order != null) {
			int index = searchOrder(order); // searchOrder 함수로 존재하는 order인지 확인하기
			if (index != -1) { // 존재하는 메뉴라면 수량만 추가하기
				Order existOrder = orders.get(index);
				int newQuantity = (existOrder.getOrderQuantity() + order.getOrderQuantity());
				// 원래 orderQuantity에 주문한 orderQuantity 더해주기
				existOrder.setOrderQuantity(newQuantity); // 더한 값으로 orderQuantity 설정하기
			} else {
				orders.add(order);
				available = false; // 사용가능 여부 불가능을 바꾸기
			}
		} else {
			//throw new IllegalArgumentException("주문이 없습니다.");
		}
	}
	
	public int searchOrder(Order order) { // order 객체 search 함수
		return orders.indexOf(order);
	}
	
	public boolean equals(Object obj) {
	    if (this == obj)
	        return true;

	    if (obj == null || getClass() != obj.getClass())
	        return false;

	    Table table = (Table) obj;

	    return id.equals(table.id);
	}
	
	public int totalPay() { // 총액 계산 함수
		int total = 0; // total 정의
		for (Order order : orders) { // 향상된 for문으로 변경
	        total += order.pay();
		}
		return total; // total 반환하기
	}
	
	public void clearOrders() { //주문 내역 초기화
	    orders.clear();
	}
	
	// 테이블 정보 저장
	public void saveTable(ObjectOutputStream oos) throws IOException {
        oos.writeUTF(id); // 테이블 id 저장
        oos.writeInt(capacity); // 수용인원 저장
        oos.writeBoolean(available); // 테이블 상태 저장
        oos.writeInt(orders.size()); // 주문 수 저장
        
        for (Order order : orders) {
            order.saveOrder(oos); // 주문 정보 저장
        }
    }
	
	// 테이블 정보 읽어오기
    public void readTable(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    	this.id = ois.readUTF(); // 아이디 불러오기
		this.capacity = ois.readInt(); // 수용인원 불러오기
		this.available = ois.readBoolean(); // 테이블 상태 불러오기
		
		int orderCount = ois.readInt(); // 주문 수 불러오기
		
		orders = new ArrayList<>(); // ArrayList 초기화

        for (int i = 0; i < orderCount; i++) {
            Order newOrder = Order.readOrder(ois);
            orders.add(newOrder); // ArrayList에 주문 추가
        }
    }
    
    // 주문 정보 저장
    public void saveOrders(ObjectOutputStream oos) throws IOException {
    	oos.writeInt(orders.size());
    	
    	for (Order order : orders) {
            order.saveOrder(oos);
        }
    }
    // 주문 정보 읽어오기
    public void readOrders(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    	int orderCount = ois.readInt(); // 주문 수 불러오기
    	
    	orders = new ArrayList<>();

        for (int i = 0; i < orderCount; i++) {
            Order newOrder = Order.readOrder(ois);
            orders.add(newOrder); // ArrayList에 주문 추가
        }
    }
    
    //------------------------------------------------------
    // 테이블 정보 저장
 	public void saveTableWithDataStream(DataOutputStream dos) throws IOException {
         dos.writeUTF(id); // 테이블 id 저장
         dos.writeInt(capacity); // 수용인원 저장
         dos.writeBoolean(available); // 테이블 상태 저장
         dos.writeInt(orders.size()); // 주문 수 저장
         
         for (Order order : orders) {
             order.saveOrderWithDataStream(dos); // 주문 정보 저장
         }
     }
 	
 	// 테이블 정보 읽어오기
     public void readTableWithDataStream(DataInputStream dis) throws IOException {
     	this.id = dis.readUTF(); // 아이디 불러오기
 		this.capacity = dis.readInt(); // 수용인원 불러오기
 		this.available = dis.readBoolean(); // 테이블 상태 불러오기
 		
 		int orderCount = dis.readInt(); // 주문 수 불러오기
 		
 		orders = new ArrayList<>(); // ArrayList 초기화

         for (int i = 0; i < orderCount; i++) {
             Order newOrder = new Order("", 0, 0);
             newOrder.readOrderWithDataStream(dis);
             orders.add(newOrder); // ArrayList에 주문 추가
         }
     }
     
     // 주문 정보 저장
     public void saveOrdersWithDataStream(DataOutputStream dos) throws IOException {
     	for (Order order : orders) {
             order.saveOrderWithDataStream(dos); // 주문 정보 저장
         }
     }
     // 주문 정보 읽어오기
     public void readOrdersWithDataStream(DataInputStream dis) throws IOException {
     	int orderCount = dis.readInt(); // 주문 수 불러오기

         for (int i = 0; i < orderCount; i++) {
             Order newOrder = new Order("", 0, 0); // Order 객체 생성
             newOrder.readOrderWithDataStream(dis); // readOrder 호출
             orders.add(newOrder); // ArrayList에 주문 추가
         }
     }

}
