import java.io.*;

public class Menu implements Serializable{
	private static final long serialVersionUID = -2573104170685902866L;
	String menuName; // 메뉴 이름 정의
	int price; // 가격 정의

	
	public Menu(String menuName, int price) { // 객체 생성
		this.menuName = menuName; 
		this.price = price;
	}
	
	public String getMenuName() {
		return menuName; // 메뉴 이름 접근자
	}
	
	public int getPrice() {
		return price; // 가격 접근자
	}
	public void setMenuName(String menuName) {
	    this.menuName = menuName; // 메뉴 이름 설정자
	}
 	public void setPrice(int price) {
        this.price = price; // 가격 설정자
    }
	 
	public boolean equals(Object obj) { // 메뉴 이름 비교 함수
	    if (this == obj)
	        return true;

	    if (obj == null || getClass() != obj.getClass())
	        return false;

	    Menu menu = (Menu) obj;

	    return menuName.equals(menu.menuName);
	}
	// 메뉴 정보 저장
	public void saveMenu(ObjectOutputStream oos)throws IOException {
		oos.writeObject(this); //FoodMenu를 직렬화하여 저장
	}
	
	// 메뉴 정보 읽어오기
	public static Menu readMenu(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        return (Menu) ois.readObject(); //역직렬화하여 FoodMenu 반환 
	} 
	//----------------------------------------------
	// 메뉴 정보 저장
	public void saveMenuWithDataStream(DataOutputStream dos)throws IOException {
		dos.writeUTF(menuName);
		dos.writeInt(price);
		//dos.writeUTF(category);
	}
	
	// 메뉴 정보 읽어오기
	public void readMenuWithDataStream(DataInputStream dis) throws IOException {
        this.menuName = dis.readUTF();
        this.price = dis.readInt();
        //his.category = dis.readUTF();
        
	} 
}
